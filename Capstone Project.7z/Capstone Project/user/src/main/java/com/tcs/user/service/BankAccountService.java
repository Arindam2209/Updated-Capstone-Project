//package com.tcs.user.service;
//
//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//@FeignClient(name="BANK-ACCOUNT",url="http://localhost:9090")
//public interface BankAccountService {
//	@DeleteMapping("/bank/user/{userId}")
//	void deleteAccounts(@PathVariable int userId);
//	
//	
//
//}
